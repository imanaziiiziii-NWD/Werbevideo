# NEWWAVE DESIGN – Video 2, freundliche Fassung

35 Sekunden, 1080 × 1920, 30 fps. Original-Logo, neue deutsche Sprachfassung,
Untertitel bei 70 % Bildhöhe, beschriftete Angebotskarten und schnellere Übergänge.
Der neue Hook: „Drei Hauspreise. Siehst du den Unterschied?“

## Vorschau und Export

```sh
npm ci
npm run dev
npx remotion render src/index.ts NWD-Angebotsvergleich out/NWD_02_Freundlich.mp4 --codec=h264 --audio-codec=aac --crf=18 --concurrency=3
```

Komposition NWD-ZweiDurchlaeufe zeigt zwei vollständige Wiederholungen.
Auf der Cloud-Maschine kann --browser-executable=/usr/bin/chromium ergänzt werden.

## Bearbeitung

Szenen und Animationen stehen in src/, Layout und Timing in Composition.tsx.
speech-script.txt enthält die überarbeitete Sprachfassung. public/voiceover.wav
und einzelne Passagen in public/voice/ sind enthalten; kein Sprachdienst ist nötig.
public/captions.json und src/captions.tsx enthalten die zeitlich angepassten Untertitel.
Die Beispielkarten behaupten keine tatsächlichen Anbieterleistungen oder Preise.
Die Preisgarantie gilt ausschließlich für unser Angebot zum vereinbarten Innenausbau.
Das Original-JPG ist unverändert. Keine Musik verwendet.

## Sprache und Lizenzen

Piper 1.8.0, Thorsten emotional medium, speaker_id=0 (amused), deutsche synthetische Stimme.
Datensatz CC0 laut beigefügter Modellkarte. DejaVu Sans: FONT-LICENSE.txt.
Zur Neusynthese generate_voice.py verwenden, Modellpfad bei Bedarf anpassen.
Modell und JSON: https://huggingface.co/rhasspy/piper-voices/tree/main/de/de_DE/thorsten_emotional/medium
prepare_captions.py nutzt erkannte Wortzeiten und den exakten Sprechertext.
Die originale Produktionsvorgabe steht in production-brief.md; diese Fassung folgt
zusätzlich dem Änderungsauftrag für freundlicheren Ton, Tempo und verständlichere Grafiken.
