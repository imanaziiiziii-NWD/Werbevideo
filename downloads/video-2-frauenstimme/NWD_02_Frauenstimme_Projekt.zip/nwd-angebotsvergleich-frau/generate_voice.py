"""Replace only the narration; preserve original scene/caption timing and 35 seconds."""
import json,wave,subprocess,tempfile,sys
from pathlib import Path
import numpy as np
from piper import PiperVoice,SynthesisConfig
root=Path(__file__).parent
cues=json.loads((root/'public/speech-cues.json').read_text())
voice=PiperVoice.load('/workspace/tts-models/kerstin.onnx')
rate=16000
track=np.zeros(35*rate,dtype=np.float64)
report=[]
def synth(text,path,scale):
 with wave.open(str(path),'wb') as w:voice.synthesize_wav(text,w,syn_config=SynthesisConfig(length_scale=scale,noise_scale=.5,noise_w_scale=.7))
 with wave.open(str(path),'rb') as w:data=np.frombuffer(w.readframes(w.getnframes()),dtype=np.int16).copy()
 active=np.where(np.abs(data.astype(np.int32))>120)[0]
 if len(active):data=data[max(0,active[0]-int(.035*rate)):min(len(data),active[-1]+int(.065*rate))]
 return data
old_report=json.loads((root/'public/voice-timing.json').read_text()) if (root/'public/voice-timing.json').exists() else []
only=int(sys.argv[1]) if len(sys.argv)>1 else None
for i,c in enumerate(cues):
 if only is not None and i!=only:
  fitted=root/'public/voice'/f'{i:02}-fitted.wav'
  with wave.open(str(fitted),'rb') as w:data=np.frombuffer(w.readframes(w.getnframes()),dtype=np.int16).copy()
  start=round(c['startMs']*rate/1000);track[start:start+len(data)]=data*.88
  report.append(old_report[i]);continue
 target=(c['endMs']-c['startMs'])/1000
 spoken_text=c['text'].replace('NEWWAVE DESIGN','Newwave Design').replace('Erstgespräch','Erst-Gespräch')
 path=root/'public/voice'/f'{i:02}.wav'
 data=synth(spoken_text,path,1)
 raw_duration=len(data)/rate
 scale=target/raw_duration
 data=synth(spoken_text,path,scale)
 with wave.open(str(path),'wb') as w:w.setnchannels(1);w.setsampwidth(2);w.setframerate(rate);w.writeframes(data.tobytes())
 # Correct small residual timing differences without changing pitch.
 ratio=len(data)/rate/target
 fitted=root/'public/voice'/f'{i:02}-fitted.wav'
 subprocess.run(['ffmpeg','-v','error','-y','-i',str(path),'-af',f'atempo={ratio:.6f},apad','-t',str(target),'-ar',str(rate),str(fitted)],check=True)
 with wave.open(str(fitted),'rb') as w:data=np.frombuffer(w.readframes(w.getnframes()),dtype=np.int16).copy()
 start=round(c['startMs']*rate/1000)
 track[start:start+len(data)]=data*.88
 report.append(dict(text=c['text'],target_seconds=target,raw_seconds=raw_duration,synthesis_length_scale=scale,residual_atempo=ratio))
 print(i,round(target,2),round(scale,2),c['text'],flush=True)
with wave.open(str(root/'public/voiceover.wav'),'wb') as w:w.setnchannels(1);w.setsampwidth(2);w.setframerate(rate);w.writeframes(track.astype(np.int16).tobytes())
(root/'public/voice-timing.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))

# Normalize only loudness; maintain the exact 35-second timing.
normalized=root/'public/voiceover-normalized.wav'
subprocess.run(['ffmpeg','-v','error','-y','-i',str(root/'public/voiceover.wav'),'-af','loudnorm=I=-16:TP=-1.5:LRA=9','-ar','16000','-t','35',str(normalized)],check=True)
normalized.replace(root/'public/voiceover.wav')
