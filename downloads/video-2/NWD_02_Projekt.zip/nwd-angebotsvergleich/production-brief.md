# NEWWAVE DESIGN – Produktionsprompts für Codex und Remotion

## Verwendung

Füge in Codex zuerst den Grundauftrag und anschließend genau einen der vier Video-Aufträge ein. Hänge das Original-Logo an. Arbeite die Videos einzeln aus, damit Gestaltung, Sprache und Tempo jeweils geprüft werden können. Die Aufträge verlangen die Erstellung und den Export; diese Datei selbst ist ein Prompt-Paket, kein bereits gerendertes Video.

Remotion ist die Grundlage für programmierte Animation, Schnitt, Untertitel und Export. Für einen fotorealistischen sprechenden Klon oder gespielte Szenen werden zusätzliche Video-/Avatar-Werkzeuge oder vorhandene Aufnahmen benötigt. Eine Sprachsynthese braucht ebenfalls einen tatsächlich verfügbaren Dienst. Die Prompts berücksichtigen diese Abhängigkeiten.

Die Farben unten sind Gestaltungsvorschläge passend zum sichtbaren Logo, keine behaupteten offiziellen Markenfarbwerte. Die Vorschläge übernehmen den dunklen Grund, Creme, Mint und gedecktes Grün. Das Original bleibt unverändert.

---

## GRUNDAUFTRAG – vor einem Video-Auftrag einfügen

Du produzierst für NEWWAVE DESIGN ein fertiges, bearbeitbares Werbevideo mit Codex und dem verfügbaren Remotion-Plugin. Setze den folgenden Video-Auftrag tatsächlich um. Liefere ein lauffähiges Projekt, eine Vorschau und nach der Prüfung einen MP4-Export. Beschränke dich nicht auf ein Konzept oder ein Drehbuch.

### Unternehmen und Aussagen

- NEWWAVE DESIGN übernimmt den Innenausbau von Fertighäusern und koordiniert weitere Gewerke. Einsatzgebiet: von Kiel bis Hannover.
- Interessenten dürfen bereits vor der Unterschrift bei einem Fertighausanbieter kommen. Auch vorhandene Kalkulationen können gemeinsam durchgegangen werden.
- Das eigene Team übernimmt den vereinbarten Innenausbau. Weitere Fachfirmen werden koordiniert; dafür werden individuelle, transparente Angebote eingeholt.
- Verbindliche Werbeformulierung: „15 Monate Preisgarantie auf unser Angebot für den vereinbarten Innenausbau.“ Nicht als Garantie für sämtliche Fremdleistungen oder als Bauzeit darstellen. Kein Startdatum, Enddatum oder Ablauf-Countdown hinzufügen und dazu keine Datumsfrage stellen.
- Das Erstgespräch ist kostenlos. Einzige gewünschte Kontaktaktion: „Kostenloses Erstgespräch vereinbaren“ über newwavedesign.de.
- Keine Fantasiepreise, Einsparsummen, Kundenbewertungen, angeblichen Referenzen oder offiziellen Partnerschaften erfinden. Keine Garantien für jederzeitige Erreichbarkeit, genehmigte Finanzierung oder völlig unterbrechungsfreie Baustellen ergänzen.
- Die Filme sprechen Privatkunden an. Vermittlerprovisionen und Verkäuferwerbung gehören nicht in diese vier Filme. Das Unternehmen nicht ohne weitere Grundlage als bereits bestehenden Generalunternehmer oder als provisionsunabhängigen Berater bezeichnen.

### Marke und Bildgestaltung

1. Öffne das beigefügte Logo und verwende genau diese Datei als Bildasset. Suche zunächst in den bereitgestellten Projektdateien. Falls das Logo tatsächlich fehlt, stelle die restliche Komposition fertig und benenne das fehlende Asset. Kein Ersatzlogo generieren.
2. Das gelieferte JPG hat einen sichtbaren dunklen Hintergrund. Behandle es als vollständige Bildmarke auf einer passenden dunklen Fläche. Keine Transparenz voraussetzen, nicht verzerren, nicht nachzeichnen und keinen Bestandteil abschneiden. Einen separaten Text „NEWWAVE DESIGN“ darfst du als Beschriftung verwenden; er ersetzt nicht das Logo.
3. Arbeitsfarben: dunkles Petrol #1D3032, Creme #F4EBCD, Mint #A4D8BD, gedecktes Grün #6A8B40. Passe die Logo-Trägerfläche bei Bedarf an die tatsächliche Bildkante an. Das Logo selbst nicht umfärben.
4. Die Bildmarke ist detailreich: während der Erklärung eine dezente Markenbeschriftung, während des Kontaktaufrufs ein ausreichend großes Original-Logo. Den eingebauten Claim nicht als winzigen Pflichttext behandeln; falls er separat erscheint, exakt „DEIN HAUS, DEINE REGELN“ schreiben.
5. Verwende eine gut lesbare, lokal verfügbare oder zulässig eingebundene Sans-Serif-Schrift. Keine Typografie, die mit der dekorativen Schrift im Logo konkurriert.

### Produktion

- Prüfe zunächst vorhandene Dateien, Projektstruktur und tatsächlich verfügbare Werkzeuge. Nutze die aktuellen Remotion-Skills für Erstellung, Markup, Untertitel und Export. Schütze bestehende Änderungen; lege bei Bedarf einen neuen Projektordner an.
- 1080 × 1920 Pixel, 9:16, 30 fps. Die angegebenen Sekunden sind ein Schnittentwurf. Zielzeit einhalten, aber die tatsächlichen Sprachpausen berücksichtigen. Keine Sprache beschleunigen, um einen zu langen Text in eine feste Szene zu pressen.
- Beginne im ersten Frame mit dem Hook-Motiv. Kein schwarzer Vorlauf, keine Begrüßung, kein Logo-Intro.
- Konservative eigene Layoutreserve: wichtige Inhalte ungefähr zwischen x=90 und x=900 sowie y=220 und y=1480 halten. Das ist eine gestalterische Reserve, keine behauptete Garantie für jede Plattformoberfläche. Beim Ziel-Export auf Lesbarkeit prüfen.
- Untertitel mit höchstens zwei Zeilen, etwa 48–60 px als Ausgangswert. Überschriften deutlich größer. Pro Einstellung nur einen Gedanken visuell hervorheben; nicht vollständige Untertitel und lange Infotexte gleichzeitig stapeln.
- Motion Design in React/TypeScript mit codebasierten SVG-/HTML-/Canvas-Elementen; räumliche Elemente bei Bedarf mit den unterstützten 3D-Werkzeugen. Skeuomorphismus entsteht durch Material, Tiefe, Licht und Bewegung, nicht allein durch abgerundete Kästen.
- Alle Animationen framebasiert mit den zur installierten Remotion-Version passenden APIs steuern. Keine zeitbasierten CSS-Animationen, zufälligen Bewegungen oder externen Live-Webseiten im Render.
- Jede Szene, Sprachspur, Clip-Ebene und wichtige Beschriftung separat bearbeitbar halten. Texte und Farben zentral pflegen. Lokale Medien im vorgesehenen Projektordner ablegen und über die unterstützten Asset-Funktionen einbinden.
- Erzeuge oder importiere zuerst die Sprachaufnahme. Stimme ruhig, verständlich und natürlich; kein übertriebener Werbeton. Erst danach Bewegungen und Untertitel präzise an den Ton anpassen. Wortweise Hervorhebung nur mit geprüften Zeitmarken.
- Prüfe, ob ein verfügbarer Dienst Sprache, Avatar oder Videos wirklich erzeugen kann. Ein vorhandener Schnitt-Plugin ist kein Beleg für diese Funktionen. Erfinde keine APIs und behaupte keine nicht erzeugten Medien. Liegt kein geeigneter Dienst oder Referenzmaterial vor, baue alle möglichen Teile und liefere eine klar als Entwurf bezeichnete Vorschau plus eine konkrete Liste fehlender Medien. Eine tonlose Vorschau gilt nicht als fertiger Film mit Sprecher.
- Wenn Bild- oder Videogenerierung erforderlich und verfügbar ist, nutze die dafür vorgesehenen Werkzeuge für die einzelnen Assets. Exakte Schrift, Logo, Angebotskarten und Untertitel werden anschließend in Remotion gesetzt.
- Musik nur aus nutzbaren Assets mit geklärten Rechten; sie ist optional. Sie muss unter der Sprache liegen. Keine Musik erfinden oder einen fremden Song ungefragt verwenden. Keine externe Veröffentlichung oder Ausgaben für Lizenzen auslösen.

### Loop und Qualitätsprüfung

- Der Loop muss sowohl sprachlich als auch visuell funktionieren. Die Handlung im letzten Moment setzt sich beim Neustart fort. Kein unnötiger doppelter Standframe, kein Schwarzbild und kein abgeschnittenes Wort am Übergang.
- Den Kontaktaufruf mehrere Sekunden vor dem Ende in die laufende Handlung integrieren. Danach zum Hook zurückführen. Keine separate lange Endkarte.
- Prüfe die komplette Vorschau mit Ton, die ersten zwei Sekunden, die Preisgarantie, den Kontaktaufruf und den Übergang bei zwei direkt aufeinanderfolgenden Wiedergaben. Bei gesprochenen Personen zusätzlich Lippenbewegung und Identitätskonsistenz prüfen.
- Kontrolliere Lesbarkeit, Überlagerungen, verzerrte Medien und sichtbare Entwurfsplatzhalter. Export und Vorschau müssen dieselben Assets verwenden.
- Bei vollständigen Medien liefere MP4 mit H.264 und AAC, eine Vorschau, bearbeitbaren Quellcode sowie das endgültige Sprechskript und passende Untertitel. Dokumentiere kurz, welche Medien extern benötigt wurden. Einen Entwurf niemals als fertigen Export ausgeben.

---

## VIDEO 1 – „Ein Schlüssel macht noch kein Zuhause“

Erstelle einen etwa 36 Sekunden langen Werbefilm mit dem Kompositionsnamen `NWD_Schluessel`. Wende den Grundauftrag an.

### Idee und Hook

Ein glänzender Schlüssel verspricht den Einzug. Hinter der attraktiven Hausfassade ist der Innenraum aber noch unausgebaut. Die erste Einstellung zeigt den Schlüssel und einen verdeckten Hinweis auf diesen Zustand. Nach dem Film versteht man den Hinweis beim erneuten Ansehen.

Der Film soll wie eine hochwertige, greifbare Architektur-Miniatur wirken. Skeuomorphismus: matte Holzoberflächen, Gipsplattenkanten, Dämmstoffstruktur, echte Lichtwirkung und weiche Kontaktschatten. Setze das Modell bevorzugt deterministisch mit Code um: als überzeugende 2,5D-Schnittzeichnung oder mit unterstütztem 3D. Keine Bauaufnahme vortäuschen. Keine generierten Texturen mit unlesbaren Schriftfragmenten.

### Sprechertext – exakt in dieser Reihenfolge

„Ein Schlüssel macht noch kein Zuhause. Je nach Ausbaustufe fehlen hinter der Fassade noch Dämmung, fertige Wände, Böden und Türen. NEWWAVE DESIGN prüft mit dir den Ausbau, kalkuliert die vereinbarten Arbeiten und koordiniert die weiteren Gewerke. Unser Team übernimmt deinen Innenausbau. Du bekommst 15 Monate Preisgarantie auf unser Angebot für den vereinbarten Umfang. Weitere Gewerke planen wir mit transparenten Angeboten. Vereinbare dein kostenloses Erstgespräch – am besten vor dem Hausvertrag. Und denk daran:“

Der Neustart vervollständigt den Schluss: „Und denk daran: Ein Schlüssel macht noch kein Zuhause.“

### Bildfolge und Synchronisierung

0–3 s: Ein Schlüssel schwingt vor der Haustür eines Miniaturhauses. Beim Wort „Zuhause“ öffnet sich die Vorderseite seitlich wie ein präzises Architekturmodell. Ein dezenter Spalt im oberen Fassadenbereich war schon im ersten Frame sichtbar. Sofort verständlicher Text: „Haus aufgestellt. Innenausbau geplant?“ Kein echtes Anbieterhaus kopieren.

3–9 s: Im offenen Haus erscheinen nacheinander Dämmung, Wandbekleidung, Boden und Tür. Jedes Bauteil nur einmal benennen und passend zum gesprochenen Wort bewegen. Zeige beispielhafte Ausbauleistungen; keine Vollständigkeit des dargestellten Bauablaufs behaupten. Einige Elemente bleiben zunächst bewusst außerhalb des Hauses liegen.

9–17 s: Eine cremefarbene Planungsfläche gleitet unter das Haus. Lose Elemente ordnen sich. Eine Person-Markierung „Dein Ansprechpartner“ verbindet die Karte „Unser Innenausbau“ mit „Weitere Fachfirmen“. Keine überfüllte Netzgrafik. Die Hausminiatur bleibt im Bild; neue Gedanken wachsen aus derselben Szene.

17–25 s: Das eigene Ausbaupaket erhält eine massive Angebotskarte. Darauf groß „15 Monate Preisgarantie“, unmittelbar darunter „Auf unser Angebot für den vereinbarten Innenausbau“. Eine separate kleinere Karte lautet „Weitere Gewerke: transparente Angebote“. Die Preisgarantie grafisch ausschließlich an das eigene Paket heften. Keine Uhr, Datumsanzeige oder Kalenderanimation.

25–32 s: Das Modell zeigt nun den gestalteten Innenraum. Kontaktaufruf als integrierte Fläche daneben: Original-Logo, „Kostenloses Erstgespräch“ und „newwavedesign.de“. „Kiel bis Hannover“ darf ergänzend erscheinen, wenn die Komposition lesbar bleibt.

32–36 s: Die Vorderseite schließt sich; die Kameraposition kehrt zur Ausgangssituation zurück. Der Schlüssel schwingt wieder zur Anfangsposition. Der letzte Bewegungszustand und der erste Frame müssen Teil derselben Bewegung sein. Die Erzählerstimme sagt „Und denk daran:“; der nächste Durchlauf liefert die Antwort.

### Ton und Abschluss

Ein präzises metallisches Schlüsselgeräusch als erster Reiz, danach dezente Materialgeräusche. Der Film soll Vertrauen erzeugen, nicht Panik. Keine lauten Warnsignale. Erzeuge die Sprachaufnahme und passe die Richtzeiten an deren echten Verlauf an. Exportiere bei vollständigem Ton `NWD_01_Schluessel.mp4` und liefere den bearbeitbaren Stand.

---

## VIDEO 2 – „Drei Hauspreise. Aber dreimal dasselbe?“

Erstelle einen etwa 35 Sekunden langen Werbefilm mit dem Kompositionsnamen `NWD_Angebotsvergleich`. Wende den Grundauftrag an.

### Idee und Hook

Drei elegante Angebotskarten wirken auf den ersten Blick vergleichbar. Eine davon liegt scheinbar vorne. Erst beim Aufklappen erkennt man: Unter den Preisüberschriften stehen unterschiedliche Leistungsumfänge. Die Pointe ist der Vergleich des Inhalts. Es werden keine tatsächlichen Preise, Anbieter oder Einsparungen behauptet.

Gestalte einen hochwertigen Wirtschaftserklärfilm. Eine matte, cremefarbene Grundfläche mit weichen Vertiefungen liefert den Neumorphismus. Darauf liegen halbtransparente Karten mit klaren Kanten, subtilen Reflexen und gut lesbarer dunkler Schrift: Glassmorphism. Drei Ebenen gleichzeitig sind die Obergrenze. Jeder neue Gedanke übernimmt ein Objekt aus dem vorherigen Bild.

### Sprechertext – exakt in dieser Reihenfolge

„Drei Hauspreise. Aber dreimal dasselbe? Ein Preis ist erst vergleichbar, wenn du weißt, was enthalten ist. Welche Ausbaustufe? Welche Technik? Welche Arbeiten kommen noch dazu? NEWWAVE DESIGN geht deine Kalkulation mit dir durch. Wir planen unseren Innenausbau und holen für weitere Gewerke transparente Angebote ein. Auf unser Angebot für den vereinbarten Innenausbau erhältst du 15 Monate Preisgarantie. Dein Erstgespräch ist kostenlos – auch wenn du noch kein Haus ausgewählt hast. Bevor du dich entscheidest, frag dich:“

Der Neustart setzt fort: „Drei Hauspreise. Aber dreimal dasselbe?“

### Bildfolge und Synchronisierung

0–3 s: Drei Karten „Angebot A“, „Angebot B“, „Angebot C“ gleiten knapp versetzt ins Bild. Zeige jeweils ein identisches neutrales Haussymbol und das Wort „Hauspreis“. Keine Eurobeträge oder Balkenhöhen erfinden. Eine Karte steht kurz vor den anderen; unmittelbar darauf klappen bei allen drei verdeckte Flächen auf. Im ersten Bild ist bereits ein kleiner Reiter „Leistungen“ zu sehen.

3–10 s: Jede Karte offenbart unterschiedlich angeordnete Leistungsbausteine. Kennzeichne die Darstellung lesbar als „Beispielhafte Darstellung“. Die drei Kategorien heißen „Ausbaustufe“, „Technik“, „Weitere Arbeiten“. Es handelt sich um ein demonstratives Modell verschiedener Umfänge, nicht um Aussagen zu echten Angeboten. Keine grüne Bewertung oder Kennzeichnung eines Gewinners verwenden.

10–18 s: Die Karten falten sich zu einer einzelnen offenen Projektübersicht. Die Wörter „Enthalten“, „Noch zu prüfen“ und „Angebot einholen“ erscheinen als Arbeitsstände; sie sind keine angeblichen Prüfergebnisse. Eine mintfarbene Linie führt jeweils nur zum aktuell erklärten Element. NEWWAVE DESIGN erscheint als Begleiter der Prüfung.

18–25 s: Zwei große, sauber getrennte Flächen bleiben sichtbar. Links: „Unser Angebot“ / „Vereinbarter Innenausbau“ / „15 Monate Preisgarantie“. Rechts: „Weitere Gewerke“ / „Transparente Angebote“. Keine Verbindung zeichnen, die die Preisgarantie auf beide Flächen überträgt. Ausreichend lange stehen lassen.

25–31 s: Beide Flächen rücken leicht auseinander und geben Raum für Original-Logo, „Kostenloses Erstgespräch“ und „newwavedesign.de“. Keine Maus simulieren, die eine Buchung bestätigt. Einblendung „Vor dem Hausvertrag oder zur Prüfung deiner Kalkulation“ nur verwenden, wenn sie ohne Textüberlastung Platz findet.

31–35 s: Die Flächen klappen zurück in die drei Karten des Anfangs. Der Sprecher beendet den Film mit „Bevor du dich entscheidest, frag dich:“. Am Übergang hat die vordere Karte exakt die Bewegung und Position, die sich im ersten Moment fortsetzt.

### Bewegung und Abschluss

Beim Vergleich fühlt sich die Bewegung leicht uneinheitlich an; bei der geordneten Prüfung wird sie ruhig und präzise. Keine dauernd pulsierenden Buttons, keine unmotivierten fliegenden Icons. Der Kontaktschritt bleibt mindestens etwa vier Sekunden gut lesbar. Stimme zuerst erzeugen; Einblendungen daran ausrichten. Exportiere `NWD_02_Angebotsvergleich.mp4` und liefere den bearbeitbaren Stand.

---

## VIDEO 3 – „Die Antwort kommt zuerst“

Erstelle einen etwa 38 Sekunden langen Podcast-Werbefilm mit dem Kompositionsnamen `NWD_Podcast`. Wende den Grundauftrag an.

### Idee und Loop

Der Film beginnt mitten in einer klaren Antwort: „Nur auf den Hauspreis schauen.“ Die Frage dazu hört man erst ganz am Ende: „Was würdest du beim Fertighauskauf niemals tun?“ Beim Neustart folgt sofort die passende Antwort. Der Loop entsteht aus einem verständlichen Gespräch und braucht keinen künstlichen Rückspul-Effekt.

### Medien und Klon

Hauptperson ist der Inhaber von NEWWAVE DESIGN. Verwende seinen autorisierten digitalen Klon oder seine echte Aufnahme. Das Logo ist keine Gesichts- oder Stimmreferenz. Prüfe deshalb zuerst, ob Referenzvideo/Bilder, Sprachreferenz und ein nutzbares Avatar-/Lippensynchronisationswerkzeug vorhanden sind.

Wenn ein geeigneter Dienst verfügbar ist, erzeuge die Antworten mit den bereitgestellten Referenzen und gleichbleibender Identität. Erfinde weder sein Aussehen noch seinen Akzent. Der Interviewer erhält eine klar unterscheidbare Stimme und bleibt vollständig außerhalb des Bildes. Sprache und Gesicht dürfen nicht unabhängig voneinander willkürlich animiert werden.

Falls die notwendigen Referenzen fehlen: erstelle das vollständige Remotion-Projekt, die Texte, Einblendungen, Schnittstruktur und eine klar gekennzeichnete Animatic. Lege die gesprochenen Passagen einzeln in der Medienliste ab. Benenne anschließend konkret die noch benötigten Aufnahmen. Kein fremdes Gesicht als vermeintlichen Inhaber einsetzen; keinen fertigen Podcast behaupten.

### Studio

Dunkles Petrol, warmes Holz, dezente mintfarbene Lichtkante. Der Inhaber sitzt leicht seitlich zu einem sichtbaren Mikrofon. Blick zum Interviewer knapp neben der Kamera. Halbnahe Einstellung, ruhige Körpersprache, Hände überwiegend im unteren Bildbereich. Eine zweite engere Einstellung nur bei der Erläuterung der Preisgarantie. Keine erfundene Sendermarke, keine Zuschauer oder Beifall.

### Exakter Dialog in Filmreihenfolge

Inhaber: „Nur auf den Hauspreis schauen.“

Interviewer: „Was fehlt in diesem Blick?“

Inhaber: „Was nach dem Aufstellen noch gemacht werden muss. Und wer diese Arbeiten plant und übernimmt.“

Interviewer: „Was macht ihr konkret?“

Inhaber: „Wir gehen die Kalkulation durch, übernehmen den vereinbarten Innenausbau und koordinieren weitere Gewerke.“

Interviewer: „Und der Preis?“

Inhaber: „Auf unser Angebot für den vereinbarten Innenausbau geben wir 15 Monate Preisgarantie. Das Erstgespräch ist kostenlos.“

Interviewer: „Also: Was würdest du beim Fertighauskauf niemals tun?“

Am Neustart antwortet der Inhaber: „Nur auf den Hauspreis schauen.“

### Schnitt und Einblendungen

0–3 s: Sofort das Gesicht und die erste Antwort. Einblendung „Vor dem Fertighausvertrag“. Kein Name als erste große Überschrift; die Aussage führt.

3–12 s: Frage und Erklärung. Maximal zwei Stichwörter nacheinander: „Leistungsumfang“ und „Umsetzung“. Kein Wechsel zu beliebigen Stockaufnahmen. Die Person bleibt Hauptmotiv.

12–22 s: Beim eigenen Team eine kleine Beschriftung „Innenausbau mit unserem Team“. Beim Koordinieren „Weitere Gewerke koordiniert“. Später ergänzende Bauaufnahmen nur nutzen, wenn sie vorhanden, geeignet und freigegeben sind.

22–31 s: Näherer Ausschnitt für die Preisgarantie. Groß „15 Monate Preisgarantie“, direkt zugeordnet „Auf unser Angebot für den vereinbarten Innenausbau“. Die Einschränkung nicht als kaum lesbare Fußnote verstecken.

31–35 s: Original-Logo als ausreichend große, aber das Gesicht nicht verdeckende Fläche. Daneben „Kostenloses Erstgespräch“ und „newwavedesign.de“. Die laufende Antwort endet natürlich.

35–38 s: Zur Ausgangseinstellung zurück. Der Inhaber hört ruhig zu. Der Interviewer stellt die Schlussfrage. Gesicht, Blick und Haltung müssen zur ersten Antwort passen. Ein natürlicher Schnitt bei gleichem Bildaufbau ist besser als ein künstlicher Gesichtsmorph.

### Ton und Abschluss

Dialog vorrangig, Musik optional. Keine künstlichen Lacher. Fragen kurz und interessiert; Antworten direkt und glaubwürdig. Passe die Richtzeiten nach den tatsächlichen Aufnahmen an. Exportiere bei vollständigen Medien `NWD_03_Podcast.mp4`. Bei fehlendem Klon liefere stattdessen die ausdrücklich benannte Entwurfsfassung und die konkrete Asset-Anforderung.

---

## VIDEO 4 – „Das hier ist günstiger“

Erstelle einen etwa 38 Sekunden langen Werbefilm mit dem Kompositionsnamen `NWD_Paar`. Wende den Grundauftrag an.

### Idee und Hook

Ein Paar sucht sein Fertighaus. Der scheinbar eindeutige Satz „Das hier ist günstiger“ kippt durch die Gegenfrage „Ist auch dasselbe drin?“. Der Zuschauer versteht sofort, warum eine schöne Hausdarstellung und ein Preis allein keine Entscheidung tragen.

Am Ende sagt der Erzähler: „Damit du weißt, was du vergleichst, wenn du sagst …“. Beim Neustart ergänzt die Person: „Das hier ist günstiger.“ Der identische Satz hat jetzt eine andere Bedeutung.

### Medienproduktion

Nutze vorhandenes geeignetes Material oder ein tatsächlich verfügbares Videogenerierungswerkzeug. Erzeuge mehrere kurze Aufnahmen mit denselben beiden erwachsenen Personen, derselben Kleidung, Wohnung und Lichtstimmung. Sichere die Identität über geeignete Referenzen. Keine angebliche echte Kundenreferenz daraus machen.

Wenige Einstellungen reichen: gemeinsamer Blick zum Laptop, Nahaufnahme Person A, Gegenschuss Person B, Hände/Unterlagen und neutraler Laptopbildschirm. Für direkte Dialoge synchronen Ton oder ein verfügbares Lip-Sync-Verfahren verwenden. Wenn das nicht gelingt, die betreffende Zeile über eine passende Aufnahme ohne sichtbaren sprechenden Mund legen. Nicht beliebig Lippenbewegungen mit fremdem Ton kombinieren.

Zeige keine echten Anbieter-Websites und lade keine Live-Seiten in den Film. Gestalte Browseroberflächen mit Remotion, neutralen Hausbildern und lesbarer Schrift. Keine Eurobeträge nötig. Auf echten Laptopaufnahmen nur eine stabile Screen-Fläche verwenden, die sich zuverlässig ersetzen lässt; andernfalls zu einer bildfüllenden Browsergrafik schneiden. Texte und Logo nie in eine generative Szene hineinmalen lassen.

Fehlen Videoerzeugung oder Aufnahmen, baue die komplette Schnittvorlage und eine ausdrücklich als Storyboard/Animatic gekennzeichnete Vorschau. Ersetze nicht heimlich die versprochene Filmszene durch bewegte Standbilder.

### Exakter Dialog und Sprechertext

Person A: „Das hier ist günstiger.“

Person B: „Ist auch dasselbe drin?“

Person A: „Keine Ahnung. Ich weiß nicht mal, welche Ausbaustufe wir brauchen.“

Person B: „Wir brauchen jemanden, der das mit uns durchgeht.“

Erzähler: „NEWWAVE DESIGN prüft mit euch die Kalkulation, plant den Innenausbau und koordiniert weitere Gewerke. Unser Team übernimmt die vereinbarten Ausbauarbeiten. Ihr bekommt einen festen Ansprechpartner und transparente Angebote. Euer Erstgespräch ist kostenlos – auch bevor ihr ein Fertighaus ausgewählt habt. Damit ihr wisst, was ihr vergleicht, wenn ihr sagt …“

Neustart mit Person A: „Das hier ist günstiger.“

### Bildfolge

0–4 s: Sofort das Paar am Laptop. Person A zeigt auf ein Angebot. Person B fragt direkt nach. Ein kleiner Zettel „Was ist enthalten?“ liegt schon im ersten Bild sichtbar neben dem Computer. Nicht als Haupttext hervorheben. Das ist das Detail, das beim erneuten Ansehen Sinn bekommt.

4–11 s: Zwei kurze Gegenschüsse. Der Browser zeigt mehrere Tabs und die Begriffe „Ausbauhaus“, „Ausbaustufe“ und „Leistungsumfang“. Natürliche Unsicherheit, keine komische Verzweiflung. Die Personen wirken fähig, aber haben noch keine Vergleichsgrundlage.

11–15 s: Person B zieht den Zettel in die Mitte. Das Rechteck des Zettels vergrößert sich und wird durch einen Match Cut zur cremefarbenen Planungsfläche. Jetzt beginnt die Markenlösung.

15–25 s: Klare Motion-Design-Sequenz im Logo-Farbsystem. Drei Arbeitsfelder bauen aufeinander auf: „Kalkulation prüfen“, „Innenausbau planen“, „Gewerke koordinieren“. Aus einer unübersichtlichen Anordnung werden geordnete Aufgaben. Eine gemeinsame Markierung „Dein Ansprechpartner“ bleibt erhalten. Nicht so darstellen, als seien ungeprüfte Positionen schon verbindlich abgeschlossen.

25–31 s: Zwei große Karten: „Unser Team: Innenausbau“ und „Weitere Gewerke: transparente Angebote“. Ein einfacher beispielhafter Ablaufstreifen zeigt die Abstimmung von Arbeiten, ohne eine konkrete Bauzeit oder garantierte Leerlauffreiheit zu behaupten. Keine zu schnelle Liste sämtlicher Gewerke.

31–35 s: Original-Logo, „Kostenloses Erstgespräch“ und „newwavedesign.de“ bleiben gut lesbar. Das Paar ist im Hintergrund wieder zu sehen, während es die Unterlagen sortiert. Nicht so darstellen, als hätte es bereits ein Haus bei NEWWAVE DESIGN gekauft.

35–38 s: Zur Kameraeinstellung des Anfangs zurück. Erzähler sagt die letzte Zeile. Die Hand von Person A beginnt dieselbe Zeigebewegung, die im ersten Frame weiterläuft. Die abschließende Formulierung darf über die vorherigen Sekunden laufen, damit der Loop nicht gehetzt klingt.

### Ton und Abschluss

Zunächst Raumton und kurze Browserklicks, später eine dezente musikalische Ordnung. Personen sprechen beiläufig und natürlich. Kein plötzlicher Trailer-Sprecher. Die Erzählerstimme soll zur Nähe der Alltagsszene passen. Exportiere bei vollständigen Medien `NWD_04_Paar.mp4` und liefere den bearbeitbaren Stand.

---

## Produktionsreihenfolge

Beginne mit Video 2: Das Verhältnis von Schrift, Formen, Farbe, Stimme und Bewegung lässt sich vollständig als programmierte Grafik ausarbeiten; eine nutzbare Sprachaufnahme wird dennoch benötigt. Danach Video 1. Für Video 3 werden die Inhaberreferenzen und ein geeignetes Avatarwerkzeug oder eine Aufnahme gebraucht. Für Video 4 werden Schauspiel-/KI-Clips gebraucht.

Ein Loop kann ein erneutes Ansehen sinnvoll machen. Er garantiert weder Zuschauerbindung noch Reichweite. Entscheidend bleibt, ob der erste Gedanke klar ist und die Antwort für Bauinteressenten nützlich ist.

## Geprüfte technische Grundlage

- Remotion Agent Skills: https://www.remotion.dev/docs/ai/skills
- Remotion Dokumentation: https://www.remotion.dev/docs/
- Zusätzlich berücksichtigt: die in dieser Sitzung verfügbaren Remotion-Skills für Erstellung, Markup und Export. In einem anderen Projekt die dort installierte Version und deren aktuelle API verwenden.
