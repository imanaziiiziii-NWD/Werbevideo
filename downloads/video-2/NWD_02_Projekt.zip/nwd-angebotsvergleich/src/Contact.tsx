import {CanvasImage,staticFile} from 'remotion';
import {project,theme as c} from './theme';
import {glass} from './Elements';
export const Contact = () => <div style={{position:'absolute',left:90,top:620,width:810}}>
 <div style={{height:350,borderRadius:30,background:c.petrol,display:'flex',alignItems:'center',justifyContent:'center',color:c.cream}}>
 {project.logoAvailable?<CanvasImage src={staticFile(project.logoFile)} style={{width:320,height:320,objectFit:'contain'}}/>:<div style={{fontSize:44,fontWeight:650}}>Original-Logo noch benötigt</div>}
 </div>
 <div style={{...glass,marginTop:25,padding:'26px 32px',color:c.petrol,fontSize:43,fontWeight:700}}>Kostenloses Erstgespräch vereinbaren</div>
 <div style={{fontSize:60,fontWeight:750,letterSpacing:-2,marginTop:24,color:c.petrol}}>newwavedesign.de</div>
 </div>;
