import {useCurrentFrame,useVideoConfig} from 'remotion';
const captions = [
  {
    "text": "Drei Hauspreise.",
    "startMs": 0,
    "endMs": 1120,
    "timestampMs": 0,
    "confidence": null
  },
  {
    "text": "Aber dreimal dasselbe?",
    "startMs": 1370,
    "endMs": 2672,
    "timestampMs": 1370,
    "confidence": null
  },
  {
    "text": "Ein Preis ist erst\nvergleichbar, wenn du weißt,",
    "startMs": 3022,
    "endMs": 5580,
    "timestampMs": 3022,
    "confidence": null
  },
  {
    "text": "was enthalten ist.",
    "startMs": 5580,
    "endMs": 6592,
    "timestampMs": 5580,
    "confidence": null
  },
  {
    "text": "Welche Ausbaustufe?",
    "startMs": 6942,
    "endMs": 8167,
    "timestampMs": 6942,
    "confidence": null
  },
  {
    "text": "Welche Technik?",
    "startMs": 8467,
    "endMs": 9311,
    "timestampMs": 8467,
    "confidence": null
  },
  {
    "text": "Welche Arbeiten\nkommen noch dazu?",
    "startMs": 9611,
    "endMs": 11337,
    "timestampMs": 9611,
    "confidence": null
  },
  {
    "text": "NEWWAVE DESIGN geht deine\nKalkulation mit dir durch.",
    "startMs": 11787,
    "endMs": 14394,
    "timestampMs": 11787,
    "confidence": null
  },
  {
    "text": "Wir planen unseren\nInnenausbau und holen für",
    "startMs": 14744,
    "endMs": 17200,
    "timestampMs": 14744,
    "confidence": null
  },
  {
    "text": "weitere Gewerke\ntransparente Angebote ein.",
    "startMs": 17200,
    "endMs": 19735,
    "timestampMs": 17200,
    "confidence": null
  },
  {
    "text": "Auf unser Angebot für den\nvereinbarten Innenausbau",
    "startMs": 20185,
    "endMs": 22920,
    "timestampMs": 20185,
    "confidence": null
  },
  {
    "text": "erhältst du 15\nMonate Preisgarantie.",
    "startMs": 22920,
    "endMs": 25239,
    "timestampMs": 22920,
    "confidence": null
  },
  {
    "text": "Dein Erstgespräch ist\nkostenlos – auch wenn du",
    "startMs": 25789,
    "endMs": 28160,
    "timestampMs": 25789,
    "confidence": null
  },
  {
    "text": "noch kein Haus\nausgewählt hast.",
    "startMs": 28160,
    "endMs": 29759,
    "timestampMs": 28160,
    "confidence": null
  },
  {
    "text": "Bevor du dich\nentscheidest, frag dich:",
    "startMs": 32879,
    "endMs": 34880,
    "timestampMs": 32879,
    "confidence": null
  }
];
export const Captions=()=>{const f=useCurrentFrame();const {fps}=useVideoConfig();const cue=captions.find(c=>f/fps*1000>=c.startMs && f/fps*1000<c.endMs);return cue?<div style={{position:'absolute',left:90,top:1344,translate:'0px -50%',width:810,textAlign:'center',fontSize:50,lineHeight:1.25,fontWeight:600,color:'#1D3032',whiteSpace:'pre-line',background:'rgba(247,242,231,.96)',borderRadius:16,padding:'16px 0'}}>{cue.text}</div>:null};
