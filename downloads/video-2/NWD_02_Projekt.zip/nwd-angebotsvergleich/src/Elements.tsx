import React from 'react';
import {theme as c} from './theme';
export const glass: React.CSSProperties = {boxSizing:'border-box',background:'linear-gradient(135deg,rgba(255,255,255,.8),rgba(255,255,255,.28))',border:'2px solid rgba(255,255,255,.9)',borderRadius:28,boxShadow:'14px 22px 40px #1d30321a, inset 2px 2px 2px white, inset -2px -2px 2px #1d30321a'};
export const House = () => <svg width="150" height="140" viewBox="0 0 150 140" fill="none"><path d="M15 62L75 18L135 62" stroke={c.petrol} strokeWidth="7" strokeLinecap="round" strokeLinejoin="round"/><path d="M32 56V120H118V56" stroke={c.petrol} strokeWidth="6"/><path d="M65 120V78H89V120M43 72H55V88H43Z" stroke={c.petrol} strokeWidth="5"/></svg>;
export const Tag = ({children}:{children:React.ReactNode}) => <div style={{fontSize:30,letterSpacing:3,textTransform:'uppercase',fontWeight:700,color:c.petrol}}>{children}</div>;
export const Headline = ({children}:{children:React.ReactNode}) => <div style={{position:'absolute',left:90,top:300,width:810,fontSize:88,lineHeight:1.06,fontWeight:750,letterSpacing:-4,color:c.petrol,whiteSpace:'pre-line'}}>{children}</div>;
