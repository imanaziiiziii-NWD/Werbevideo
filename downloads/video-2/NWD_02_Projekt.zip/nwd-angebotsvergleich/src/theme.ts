export const theme = {petrol:'#1D3032', cream:'#F4EBCD', mint:'#A4D8BD', green:'#6A8B40', paper:'#F7F2E7', ink:'#203436'};
export const project = {logoAvailable:true, logoFile:'logo-original.jpg', draft:false, duration:35, fps:30};
