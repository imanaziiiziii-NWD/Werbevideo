import {interpolate,useCurrentFrame,useVideoConfig} from 'remotion';
import {glass,House} from './Elements';
import {theme as c} from './theme';
type CardProps={letter:string;left:number;delay:number;returning?:boolean};
export const OfferCard = ({letter,left,delay,returning=false}:CardProps) => {
 const f=useCurrentFrame();const {fps}=useVideoConfig();const t=f/fps;
 const phase=returning?t+32.7:t;
 const merge=returning?0:interpolate(t,[11.15,11.9],[0,1],{extrapolateLeft:'clamp',extrapolateRight:'clamp'});
 const lift=14*Math.sin(2*Math.PI*phase/35)+(returning?0:interpolate(t,[0,.9,2.2,3.4],[0,0,delay===0?-25:0,0],{extrapolateRight:'clamp'}));
 const open=returning?0:interpolate(t,[2.5+delay*.1,4.1+delay*.1],[0,1],{extrapolateLeft:'clamp',extrapolateRight:'clamp'});
 return <div style={{...glass,boxSizing:'border-box',position:'absolute',left:left+(90-left)*merge,top:660-35*merge,width:258+552*merge,height:390+225*merge,padding:18,color:c.petrol,translate:`0px ${lift*(1-merge)}px`,rotate:`${.7*Math.sin(2*Math.PI*phase/35)*(1-merge)}deg`,perspective:1000,opacity:delay===0?1:1-merge}}>
 <div style={{opacity:1-merge}}>
  <div style={{fontSize:42,fontWeight:750,whiteSpace:'nowrap'}}>Angebot {letter}</div>
  <div style={{fontSize:42,marginTop:16}}>Hauspreis</div>
  <div style={{display:'flex',justifyContent:'center',marginTop:27}}><House/></div>
  <div style={{position:'absolute',bottom:18,left:24,fontSize:28,borderBottom:`2px solid ${c.petrol}`,paddingBottom:4}}>Leistungen ↗</div>
  <div style={{position:'absolute',inset:'160px 16px 12px',borderRadius:16,background:'linear-gradient(130deg,#edf4e9,#f7f2e7)',boxShadow:'0 -4px 12px #2034361b',transformOrigin:'bottom',transform:`rotateX(${(1-open)*90}deg)`,opacity:open,padding:18}}>
   <div style={{fontSize:26,fontWeight:650,marginBottom:17}}>Leistungsumfang</div>
   {[0,1,2].map((row)=><div key={row} style={{height:28,display:'flex',gap:8,marginBottom:20}}>{Array.from({length:[2,3,1][(row+delay)%3]},(_,j)=><div key={j} style={{width:42,height:28,borderRadius:6,background:row===1?'#A4D8BD':'#d9ddcc',boxShadow:'inset 2px 2px 3px white,inset -2px -2px 3px #20343622'}}/>)}</div>)}
  </div>
 </div>
 </div>;
};
export const Offers = ({returning=false}:{returning?:boolean}) => {
 const f=useCurrentFrame();const {fps}=useVideoConfig();const t=f/fps;
 return <>
 <OfferCard letter="A" left={90} delay={0} returning={returning}/>
 <OfferCard letter="B" left={366} delay={1} returning={returning}/>
 <OfferCard letter="C" left={642} delay={2} returning={returning}/>
 {!returning && t>3 && <div style={{position:'absolute',left:90,top:1090,width:810,color:c.petrol}}><div style={{fontSize:42,fontWeight:600}}>Ausbaustufe · Technik</div><div style={{fontSize:42,fontWeight:600,marginTop:10}}>Weitere Arbeiten</div><div style={{fontSize:30,marginTop:28}}>Beispielhafte Darstellung</div></div>}
 </>;
};
