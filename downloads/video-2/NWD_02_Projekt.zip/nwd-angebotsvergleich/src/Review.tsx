import {interpolate,useCurrentFrame,useVideoConfig} from 'remotion';
import {glass} from './Elements';
import {theme as c} from './theme';
export const Review = () => {
 const f=useCurrentFrame();const {fps}=useVideoConfig();const t=f/fps;
 const active=t<2?0:t<4?1:2;
 return <div style={{...glass,position:'absolute',left:90,top:625,width:810,height:615,padding:52}}>
 <div style={{fontSize:32,letterSpacing:3,color:c.petrol,marginBottom:38}}>DEINE PROJEKTÜBERSICHT</div>
 <div style={{position:'absolute',left:36,top:145+active*137,width:5,height:85,background:c.mint,boxShadow:'0 0 12px #A4D8BD'}}/>
 <div style={{fontSize:51,fontWeight:650,color:c.petrol,padding:'30px 15px',borderBottom:'1px solid #1d303220',opacity:interpolate(t,[0,.5],[.6,1],{extrapolateRight:'clamp'})}}>Enthalten</div>
 <div style={{fontSize:51,fontWeight:650,color:c.petrol,padding:'30px 15px',borderBottom:'1px solid #1d303220'}}>Noch zu prüfen</div>
 <div style={{fontSize:51,fontWeight:650,color:c.petrol,padding:'30px 15px'}}>Angebot einholen</div>
 <div style={{fontSize:29,color:c.petrol,marginTop:26}}>Arbeitsstände – keine Prüfergebnisse</div>
 </div>;
};
