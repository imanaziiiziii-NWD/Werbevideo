import React from 'react';
import {AbsoluteFill,Composition,Sequence,interpolate,staticFile,useCurrentFrame,useVideoConfig} from 'remotion';
import {Audio} from '@remotion/media';
import {Offers} from './Offers';
import {Review} from './Review';
import {Guarantee} from './Guarantee';
import {Contact} from './Contact';
import {Headline} from './Elements';
import {project,theme as c} from './theme';
import {Captions} from './captions';

const Stage = ({start,end,children}:{start:number;end:number;children:React.ReactNode}) => {
 const f=useCurrentFrame();const {fps}=useVideoConfig();const t=f/fps;
 const opacity=interpolate(t,[start,start+.4,end-.4,end],[0,1,1,0],{extrapolateLeft:'clamp',extrapolateRight:'clamp'});
 return <AbsoluteFill style={{opacity,translate:`0px ${interpolate(t,[start,start+.5],[35,0],{extrapolateLeft:'clamp',extrapolateRight:'clamp'})}px`}}>{children}</AbsoluteFill>;
};
export const Film = ({mute=false}:{mute?:boolean}) => {
 const f=useCurrentFrame();const {fps}=useVideoConfig();const t=f/fps;
 const title=t<3?'Drei Hauspreise.\nDreimal dasselbe?':t<11.8?'Vergleiche\nden Inhalt.':t<20.1?'Gemeinsam\nKlarheit schaffen.':t<25.65?'Klar getrennt.\nTransparent geplant.':t<32.9?'Dein Haus.\nDeine Entscheidung.':'Bevor du dich\nentscheidest …';
 const deckOpacity=t<11.2?1:interpolate(t,[11.2,11.9],[1,0],{extrapolateRight:'clamp'});
 const returnOpacity=interpolate(t,[32.7,34.45],[0,1],{extrapolateLeft:'clamp',extrapolateRight:'clamp'});
 return <AbsoluteFill style={{background:'radial-gradient(ellipse at 18% 20%,#fffdf6 0%,#F4EBCD 63%,#dfdfc9 100%)',fontFamily:'NwdSans, sans-serif',color:c.petrol}}>
 <style>{`@font-face{font-family:NwdSans;src:url(${staticFile('sans.ttf')});font-weight:100 900}`}</style>
 <div style={{position:'absolute',left:90,top:220,fontSize:27,letterSpacing:4,fontWeight:700}}>NEWWAVE DESIGN <span style={{fontWeight:400,letterSpacing:1}}> / ANGEBOTSVERGLEICH</span></div>
 <div style={{position:'absolute',left:90,top:165,fontSize:23,color:'#7a4d32'}}>{project.draft?'ENTWURF · ORIGINAL-LOGO FEHLT':''}</div>
 <div style={{opacity:t<32.7?1:interpolate(t,[32.7,34.65],[1,0],{extrapolateRight:'clamp'})}}><Headline>{title}</Headline></div>
 <div style={{opacity:interpolate(t,[34.35,35],[0,1],{extrapolateLeft:'clamp',extrapolateRight:'clamp'})}}><Headline>{'Drei Hauspreise.\nDreimal dasselbe?'}</Headline></div>
 <AbsoluteFill style={{opacity:deckOpacity}}><Offers/></AbsoluteFill>
 <Stage start={11.35} end={20.4}><Sequence from={11.35*fps} premountFor={fps}><Review/></Sequence></Stage>
 <Stage start={19.9} end={26}><Sequence from={19.9*fps} premountFor={fps}><Guarantee/></Sequence></Stage>
 <Stage start={25.5} end={33.2}><Sequence from={25.5*fps} premountFor={fps}><Contact/></Sequence></Stage>
 <AbsoluteFill style={{opacity:returnOpacity}}><Sequence from={32.7*fps} premountFor={fps}><Offers returning/></Sequence></AbsoluteFill>
 <Captions/>
 {!mute && <Audio src={staticFile('voiceover.wav')} premountFor={fps}/>}
 </AbsoluteFill>;
};
export const TwoLoops = () => {const {fps}=useVideoConfig();return <><Sequence durationInFrames={35*fps} premountFor={fps}><Film/></Sequence><Sequence from={35*fps} durationInFrames={35*fps} premountFor={fps}><Film/></Sequence></>};
export const MyComposition = () => <>
 <Composition id="NWD-Angebotsvergleich" component={Film} durationInFrames={1050} fps={30} width={1080} height={1920} defaultProps={{mute:false}}/>
 <Composition id="NWD-ZweiDurchlaeufe" component={TwoLoops} durationInFrames={2100} fps={30} width={1080} height={1920}/>
 <Composition id="Szene-Angebote" component={Offers} durationInFrames={354} fps={30} width={1080} height={1920}/>
 <Composition id="Szene-Pruefung" component={Review} durationInFrames={270} fps={30} width={1080} height={1920}/>
 <Composition id="Szene-Preisgarantie" component={Guarantee} durationInFrames={183} fps={30} width={1080} height={1920}/>
 <Composition id="Szene-Kontakt" component={Contact} durationInFrames={231} fps={30} width={1080} height={1920}/>
 </>;
