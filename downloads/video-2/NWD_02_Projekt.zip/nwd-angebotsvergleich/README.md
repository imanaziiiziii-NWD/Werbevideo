# NEWWAVE DESIGN — Drei Hauspreise. Aber dreimal dasselbe?

Bearbeitbares Remotion-Projekt, 1080 × 1920, 30 fps, 35 Sekunden.

## Status

Finaler Projektstand mit unveränderter Original-JPG-Bildmarke, deutscher Sprachfassung, Animationen und Untertiteln. Keine Medien fehlen. Musik ist bewusst nicht Bestandteil des Films.

## Installation und Vorschau

Node.js 24, npm 11 wurden verwendet. Ein vorhandener Checkout genügt; kein Git-Worktree ist nötig.

```sh
npm ci
npm run dev -- --no-open
```

Im Remotion Studio `NWD-Angebotsvergleich` auswählen. `NWD-ZweiDurchlaeufe` dient der Prüfung der vollständigen Schleife. Das vom Brief verlangte `NWD_Angebotsvergleich` ist als ID in Remotion 4.0.534 wegen des Unterstrichs nicht zulässig; deshalb wird die gleichnamige Komposition mit Bindestrich registriert.

## Export

```sh
npx remotion render src/index.ts NWD-Angebotsvergleich out/NWD_02_Angebotsvergleich.mp4 --codec=h264 --audio-codec=aac --crf=18 --concurrency=3
```

Bei fehlendem mitgelieferten Browser kann `--browser-executable=/usr/bin/chromium` auf dieser Cloud-Maschine ergänzt werden. Die Original-Bildmarke ist bereits integriert.

## Bearbeitung

- `src/Offers.tsx`: drei Angebotskarten, aufklappbare Leistungsflächen und Zusammenführung.
- `src/Review.tsx`: Arbeitsstände der gemeinsamen Prüfung.
- `src/Guarantee.tsx`: getrennte Angebote, Preisgarantie nur für den vereinbarten Innenausbau.
- `src/Contact.tsx`: Bildmarke und einziger Kontaktaufruf.
- `src/Composition.tsx`: Szenentiming, Überschriften, Sprachspur und Schleife.
- `src/theme.ts`: Farben und Assetstatus.
- `src/captions.tsx` / `public/captions.json`: höchstens zweizeilige, editierbare Untertitel bei 70 % Bildhöhe.
- `speech-script.txt`: endgültiger, unveränderter Sprechertext aus Video 2.
- `public/voiceover.wav`: tatsächlich lokal erzeugte deutsche Sprachaufnahme.
- `public/voice/`: einzelne Sprachpassagen.

## Sprachproduktion und Rechte

Piper TTS 1.8.0, deutsche Thorsten-medium-Stimme, 22.05 kHz. Stimmen-Datensatz laut beigefügter Modellkarte CC0. Keine Stimmklonung, kein bezahlter Dienst. Modell: https://huggingface.co/rhasspy/piper-voices/tree/main/de/de_DE/thorsten/medium . Quellhinweis und Modellkarte in `public/voice/MODEL_CARD.txt`. Schrift: lokale DejaVu Sans (Lizenz in `FONT-LICENSE.txt`). Keine externen Bilder, Referenzen, Anbieter oder tatsächlichen Preise wurden erfunden.

Die elf Sätze werden mit `generate_voice.py` synthetisiert und nur an stillen Rändern gekürzt, ohne Beschleunigung. Die vorhandenen WAV-Dateien können ohne TTS-Werkzeuge benutzt werden. Für erneute Synthese Piper installieren und die ONNX-Datei samt JSON-Konfiguration herunterladen. Das Skript erwartet die Modelle aktuell unter `/workspace/tts-models/`; diesen Pfad bei Bedarf anpassen. Zusätzliche natürliche Pause beim Kontaktaufruf bringt die Dauer auf 35 Sekunden.

Die Sprachverständlichkeit wurde zusätzlich mit lokaler Whisper-small-Erkennung geprüft. Für Caption-Regeneration nutzt `prepare_captions.py` die tatsächlichen Wortzeitmarken aus `public/recognized.json` und den exakten Sprechertext; es gibt keine ungeprüfte wortweise Hervorhebung.

## Prüfungen

TypeScript-Kompilierung; Remotion Studio im lokalen Chromium geöffnet; mehrere Schlüsselframes geprüft, Website-/Untertitelüberlagerung korrigiert. H.264/AAC-Export und zwei zusammenhängende Durchläufe werden technisch geprüft. Eine subjektive Hörabnahme durch den Nutzer bleibt sinnvoll.
