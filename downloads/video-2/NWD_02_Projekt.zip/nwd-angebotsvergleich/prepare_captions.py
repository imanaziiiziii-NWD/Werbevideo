import json, re, difflib
from pathlib import Path
from PIL import ImageFont
root=Path(__file__).parent
cues=json.loads((root/'public/speech-cues.json').read_text())
heard=json.loads((root/'public/recognized.json').read_text())
font=ImageFont.truetype(str(root/'public/sans.ttf'),50)
def norm(s):return re.sub(r'[^a-zäöüß0-9]','',s.lower())
def layout(text):
    if font.getlength(text)<=800:return [text]
    ws=text.split()
    if len(ws)<2:return [text]
    return min([[' '.join(ws[:k]),' '.join(ws[k:])] for k in range(1,len(ws))],key=lambda p:max(font.getlength(l) for l in p))
pages=[]
for cue in cues:
    tokens=cue['text'].split()
    hs=[w for w in heard if w['startMs']>=cue['startMs']-100 and w['startMs']<cue['endMs']]
    matcher=difflib.SequenceMatcher(None,[norm(t) for t in tokens],[norm(w['text']) for w in hs],autojunk=False)
    starts={}
    for block in matcher.get_matching_blocks():
        for k in range(block.size):starts[block.a+k]=hs[block.b+k]['startMs']
    groups=[];group=[]
    for i in range(len(tokens)):
        text=' '.join(tokens[j] for j in group+[i])
        if group and (max(font.getlength(l) for l in layout(text))>800 or len(group)>=8):
            groups.append(group);group=[]
        group.append(i)
    if group:groups.append(group)
    if len(groups)>1 and len(groups[-1])<3:
        candidate=groups[-2][-2:]+groups[-1]
        if max(font.getlength(l) for l in layout(' '.join(tokens[j] for j in candidate)))<=800:
            groups[-1]=candidate;groups[-2]=groups[-2][:-2]
    for gi,g in enumerate(groups):
        if not g:continue
        def time(index):return starts.get(index,cue['startMs']+round((cue['endMs']-cue['startMs'])*index/len(tokens)))
        start=cue['startMs'] if gi==0 else time(g[0])
        end=time(groups[gi+1][0]) if gi+1<len(groups) else cue['endMs']
        text='\n'.join(layout(' '.join(tokens[j] for j in g)))
        assert start<end and len(text.split('\n'))<=2
        pages.append({'text':text,'startMs':start,'endMs':end,'timestampMs':start,'confidence':None})
(root/'public/captions.json').write_text(json.dumps(pages,ensure_ascii=False,indent=2))
source="import {useCurrentFrame,useVideoConfig} from 'remotion';\nconst captions = "+json.dumps(pages,ensure_ascii=False,indent=2)+";\nexport const Captions=()=>{const f=useCurrentFrame();const {fps}=useVideoConfig();const cue=captions.find(c=>f/fps*1000>=c.startMs && f/fps*1000<c.endMs);return cue?<div style={{position:'absolute',left:90,top:1344,translate:'0px -50%',width:810,textAlign:'center',fontSize:50,lineHeight:1.25,fontWeight:600,color:'#1D3032',whiteSpace:'pre-line',background:'rgba(247,242,231,.96)',borderRadius:16,padding:'16px 0'}}>{cue.text}</div>:null};\n"
(root/'src/captions.tsx').write_text(source)
def stamp(ms):
    h,ms=divmod(ms,3600000);m,ms=divmod(ms,60000);s,ms=divmod(ms,1000)
    return f'{h:02}:{m:02}:{s:02},{ms:03}'
(root/'NWD_02_Untertitel.srt').write_text('\n\n'.join(f'{i+1}\n{stamp(c["startMs"])} --> {stamp(c["endMs"])}\n{c["text"]}' for i,c in enumerate(pages))+'\n')
print(len(pages),'subtitle pages prepared')
