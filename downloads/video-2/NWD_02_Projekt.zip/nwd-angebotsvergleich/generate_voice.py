import json, wave
from pathlib import Path
import numpy as np
from piper import PiperVoice

root = Path(__file__).parent
lines = [
 'Drei Hauspreise.',
 'Aber dreimal dasselbe?',
 'Ein Preis ist erst vergleichbar, wenn du weißt, was enthalten ist.',
 'Welche Ausbaustufe?',
 'Welche Technik?',
 'Welche Arbeiten kommen noch dazu?',
 'NEWWAVE DESIGN geht deine Kalkulation mit dir durch.',
 'Wir planen unseren Innenausbau und holen für weitere Gewerke transparente Angebote ein.',
 'Auf unser Angebot für den vereinbarten Innenausbau erhältst du 15 Monate Preisgarantie.',
 'Dein Erstgespräch ist kostenlos – auch wenn du noch kein Haus ausgewählt hast.',
 'Bevor du dich entscheidest, frag dich:',
]
voice = PiperVoice.load('/workspace/tts-models/thorsten.onnx')
parts, cues, spoken = [], [], []
elapsed = 0
for i, text in enumerate(lines):
    target = root / 'public' / 'voice' / f'{i:02}.wav'
    with wave.open(str(target), 'wb') as w:
        voice.synthesize_wav(text, w)
    with wave.open(str(target), 'rb') as w:
        rate = w.getframerate()
        data = np.frombuffer(w.readframes(w.getnframes()), dtype=np.int16)
    # Remove only silence; speech is never sped up.
    active = np.where(np.abs(data.astype(np.int32)) > 150)[0]
    if len(active):
        data = data[max(0,active[0]-int(.045*rate)):min(len(data),active[-1]+int(.10*rate))]
    duration = len(data)/rate
    spoken.append(data)
    print(i, round(duration,2), text, flush=True)
gaps = [.25,.35,.35,.30,.30,.45,.35,.45,.55,.35,.12]
gaps[9] += max(0, 35 - sum(len(d)/rate for d in spoken) - sum(gaps))
for i, (text, data) in enumerate(zip(lines, spoken)):
    duration = len(data)/rate
    cues.append({'text':text,'startMs':round(elapsed*1000),'endMs':round((elapsed+duration)*1000),'timestampMs':round(elapsed*1000),'confidence':None,'scene':i})
    parts.extend([data, np.zeros(round(gaps[i]*rate),dtype=np.int16)])
    elapsed += duration + gaps[i]
audio = (np.concatenate(parts).astype(np.float64) * .85).astype(np.int16)
with wave.open(str(root/'public'/'voiceover.wav'),'wb') as w:
    w.setnchannels(1); w.setsampwidth(2); w.setframerate(rate); w.writeframes(audio.tobytes())
(root/'public'/'speech-cues.json').write_text(json.dumps(cues,ensure_ascii=False,indent=2))
(root/'speech-script.txt').write_text(' '.join(lines)+'\n')
print('Duration:',round(elapsed,3))
