# NEWWAVE DESIGN – neue Sprachfassung Serena

35 Sekunden, 1080 × 1920, 30 fps. Das freigegebene Video bleibt erhalten.
Die Sprachspur wurde mit einem anderen Sprachmodell neu erzeugt:
Qwen3-TTS-12Hz-0.6B-CustomVoice, weibliche Stimme Serena, Sprache German, 24 kHz.

## Vorschau und Export

```sh
npm ci
npm run dev
npx remotion render src/index.ts NWD-Angebotsvergleich out/NWD_02_Serena.mp4 --codec=h264 --audio-codec=aac --crf=18 --concurrency=3
```

Die mitgelieferte MP4 verwendet die ursprüngliche H.264-Bildspur ohne erneute
Komprimierung. Der obige Befehl erzeugt einen neuen Export aus dem bearbeitbaren Projekt.

## Sprachspur

public/voiceover.wav enthält die vollständige neue Aufnahme.
public/voice/ enthält einzelne Originalaufnahmen und angepasste WAV-Passagen.
generate_voice.py erzeugt und integriert die elf Sätze. Zur Neusynthese:

```sh
python -m venv .voice-env
.voice-env/bin/pip install torch torchaudio --index-url https://download.pytorch.org/whl/cpu
.voice-env/bin/pip install -r voice-requirements.txt
```

Das Modell ist nicht im ZIP enthalten. Herunterladen von:
https://huggingface.co/Qwen/Qwen3-TTS-12Hz-0.6B-CustomVoice
Alle Modelldateien einschließlich speech_tokenizer/ nach /workspace/tts-models/qwen-natural
kopieren oder den Pfad in generate_voice.py anpassen. FFmpeg wird zusätzlich benötigt.

```sh
HF_HUB_OFFLINE=1 .voice-env/bin/python generate_voice.py
```

Das Skript lässt vorhandene Sprachaufnahmen im voice/-Ordner stehen, um Fortsetzungen
zu ermöglichen. Für eine komplette Neusynthese zuvor diese WAV-Dateien entfernen.
Die Sätze nutzen die ursprünglichen Startzeiten. Bei Bedarf wird eine bestehende stille
Pause mitgenutzt. Eine Tempoanpassung erhält die Tonhöhe; die Spur endet nach 35 Sekunden.
public/voice-timing.json dokumentiert die tatsächlichen Sprachzeiten und Anpassungen.
Die ursprünglich eingebrannten Untertitel werden unverändert beibehalten;
public/recognized.json enthält die ursprünglichen Wortzeiten für dieses feste Layout.

## Bearbeitung und Rechte

Szenen und Animationen: src/. Sprechertext: speech-script.txt.
Logo: public/logo-original.jpg, unveränderte Originaldatei.
Untertitel: public/captions.json und src/captions.tsx, 70 % Bildhöhe.
Modell: Apache 2.0; Modellkarte und Lizenz stehen in public/voice/.
Schrift: DejaVu Sans, FONT-LICENSE.txt. Keine Musik verwendet.
Die Preisgarantie bezieht sich nur auf das Angebot für den vereinbarten Innenausbau.
Die Stimme ist eine synthetische Modellstimme, keine geklonte Person.
