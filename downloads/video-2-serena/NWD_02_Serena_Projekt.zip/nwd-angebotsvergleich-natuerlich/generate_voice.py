"""Generate a new female narration with Qwen3-TTS; retain original video and 35s duration."""
import json, time, subprocess
from pathlib import Path
import numpy as np
import soundfile as sf
import torch
from qwen_tts import Qwen3TTSModel
root=Path(__file__).parent
cues=json.loads((root/'public/speech-cues.json').read_text())
torch.set_num_threads(4);torch.set_num_interop_threads(1);torch.manual_seed(42)
model=Qwen3TTSModel.from_pretrained('/workspace/tts-models/qwen-natural',device_map='cpu',dtype=torch.bfloat16,attn_implementation='sdpa')
print('Natural voice model loaded',flush=True)
track=np.zeros(35*24000,dtype=np.float32);report=[]
for i,c in enumerate(cues):
 begin=time.time();text=c['text'].replace('NEWWAVE DESIGN','New Wave Design')
 raw=root/'public/voice'/f'{i:02}.wav';fitted=root/'public/voice'/f'{i:02}-fitted.wav'
 if raw.exists() and (root/'public/voice/QWEN_MODEL_CARD.md').exists():
  data,sr=sf.read(raw)
 else:
  wavs,sr=model.generate_custom_voice(text=text,language='German',speaker='Serena',max_new_tokens=180,do_sample=True,temperature=.7,top_p=.9)
  data=wavs[0]
  # Trim quiet edges only, preserving articulation and natural breaths.
  energy=np.abs(data);active=np.where(energy>.008)[0]
  if len(active):data=data[max(0,active[0]-int(.035*sr)):min(len(data),active[-1]+int(.07*sr))]
  sf.write(raw,data,sr)
 duration=len(data)/sr
 original=(c['endMs']-c['startMs'])/1000
 available=((cues[i+1]['startMs']-80) if i+1<len(cues) else 34880)-c['startMs']
 available/=1000
 # Borrow only the existing silent gap when a short phrase would otherwise be rushed.
 target=min(available,max(original,duration/1.15))
 ratio=duration/target
 subprocess.run(['ffmpeg','-v','error','-y','-i',str(raw),'-af',f'atempo={ratio:.6f},apad','-t',str(target),'-ar','24000',str(fitted)],check=True)
 samples,_=sf.read(fitted,dtype='float32');start=round(c['startMs']*24)
 track[start:start+len(samples)]=samples
 report.append(dict(text=c['text'],startMs=c['startMs'],endMs=round(c['startMs']+target*1000),raw_seconds=duration,pitch_preserving_tempo=ratio))
 print(i,'generated in',round(time.time()-begin,1),'audio',round(duration,2),'fit',round(target,2),'ratio',round(ratio,3),text,flush=True)
sf.write(root/'public/voiceover-raw.wav',track,24000)
subprocess.run(['ffmpeg','-v','error','-y','-i',str(root/'public/voiceover-raw.wav'),'-af','loudnorm=I=-16:TP=-1.5:LRA=9','-ar','24000','-t','35',str(root/'public/voiceover.wav')],check=True)
(root/'public/voice-timing.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
print('Complete: 35-second female narration',flush=True)
