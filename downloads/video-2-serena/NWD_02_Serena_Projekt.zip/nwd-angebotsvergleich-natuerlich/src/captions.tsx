import {useCurrentFrame,useVideoConfig} from 'remotion';
const captions = [
  {
    "text": "Drei Hauspreise.",
    "startMs": 0,
    "endMs": 1161,
    "timestampMs": 0,
    "confidence": null
  },
  {
    "text": "Siehst du den Unterschied?",
    "startMs": 1411,
    "endMs": 2560,
    "timestampMs": 1411,
    "confidence": null
  },
  {
    "text": "Der steckt im\nInhalt. Schauen",
    "startMs": 2910,
    "endMs": 4320,
    "timestampMs": 2910,
    "confidence": null
  },
  {
    "text": "wir gemeinsam\ngenauer hin.",
    "startMs": 4320,
    "endMs": 5859,
    "timestampMs": 4320,
    "confidence": null
  },
  {
    "text": "Welche Ausbaustufe?",
    "startMs": 6209,
    "endMs": 7463,
    "timestampMs": 6209,
    "confidence": null
  },
  {
    "text": "Welche Technik?",
    "startMs": 7763,
    "endMs": 8634,
    "timestampMs": 7763,
    "confidence": null
  },
  {
    "text": "Welche Arbeiten\nkommen noch dazu?",
    "startMs": 8934,
    "endMs": 10815,
    "timestampMs": 8934,
    "confidence": null
  },
  {
    "text": "Mit NEWWAVE DESIGN\nbringst du Klarheit",
    "startMs": 11265,
    "endMs": 13380,
    "timestampMs": 11265,
    "confidence": null
  },
  {
    "text": "in deine Kalkulation.",
    "startMs": 13380,
    "endMs": 14783,
    "timestampMs": 13380,
    "confidence": null
  },
  {
    "text": "Wir planen unseren\nInnenausbau und holen für",
    "startMs": 15133,
    "endMs": 17940,
    "timestampMs": 15133,
    "confidence": null
  },
  {
    "text": "weitere Gewerke\ntransparente Angebote ein.",
    "startMs": 17940,
    "endMs": 20671,
    "timestampMs": 17940,
    "confidence": null
  },
  {
    "text": "Auf unser Angebot für den\nvereinbarten Innenausbau",
    "startMs": 21121,
    "endMs": 24020,
    "timestampMs": 21121,
    "confidence": null
  },
  {
    "text": "erhältst du 15 Monate\nPreisgarantie.",
    "startMs": 24020,
    "endMs": 26322,
    "timestampMs": 24020,
    "confidence": null
  },
  {
    "text": "Dein Erstgespräch ist\nkostenlos – auch wenn du",
    "startMs": 26872,
    "endMs": 29860,
    "timestampMs": 26872,
    "confidence": null
  },
  {
    "text": "noch kein Haus\nausgewählt hast.",
    "startMs": 29860,
    "endMs": 31527,
    "timestampMs": 29860,
    "confidence": null
  },
  {
    "text": "Bevor du dich\nentscheidest, frag dich:",
    "startMs": 32616,
    "endMs": 34880,
    "timestampMs": 32616,
    "confidence": null
  }
];
export const Captions=()=>{const f=useCurrentFrame();const {fps}=useVideoConfig();const cue=captions.find(c=>f/fps*1000>=c.startMs && f/fps*1000<c.endMs);return cue?<div style={{position:'absolute',left:90,top:1344,translate:'0px -50%',width:810,textAlign:'center',fontSize:50,lineHeight:1.25,fontWeight:600,color:'#1D3032',whiteSpace:'pre-line',background:'rgba(247,242,231,.96)',borderRadius:16,padding:'16px 0'}}>{cue.text}</div>:null};
