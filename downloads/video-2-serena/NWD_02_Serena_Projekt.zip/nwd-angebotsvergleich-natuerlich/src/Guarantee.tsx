import {interpolate,useCurrentFrame,useVideoConfig} from 'remotion';
import {glass} from './Elements';
import {theme as c} from './theme';
export const Guarantee = () => {
 const f=useCurrentFrame();const {fps}=useVideoConfig();
 return <div style={{position:'absolute',left:90,top:620,width:810,display:'flex',gap:30,translate:`0px ${interpolate(f,[0,fps*.6],[16,0],{extrapolateRight:'clamp'})}px`}}>
 <div style={{...glass,padding:28,width:390,background:'linear-gradient(120deg,#203638,#1D3032)',color:c.cream,height:600,border:'2px solid #A4D8BD44'}}>
 <div style={{fontSize:36,fontWeight:600}}>Unser Angebot</div>
 <div style={{fontSize:132,lineHeight:1.02,fontWeight:750,letterSpacing:-3,marginTop:30}}>15</div>
 <div style={{fontSize:55,fontWeight:650,marginTop:3}}>Monate</div>
 <div style={{fontSize:36,fontWeight:650,marginTop:16}}>Preisgarantie</div>
 <div style={{fontSize:36,lineHeight:1.2,marginTop:35,color:c.mint}}>Für den<br/>vereinbarten<br/>Innenausbau</div>
 </div>
 <div style={{...glass,width:390,height:600,padding:28,color:c.petrol}}><div style={{fontSize:51,lineHeight:1.14,fontWeight:700}}>Weitere<br/>Gewerke</div><div style={{height:2,background:'#20343622',marginTop:55,marginBottom:45}}/><div style={{fontSize:34,lineHeight:1.25}}>Transparente<br/>Angebote</div></div>
 </div>;
};
