import {interpolate,useCurrentFrame,useVideoConfig} from 'remotion';
import {glass,House} from './Elements';
import {theme as c} from './theme';
const names=['Ausbaustufe','Technik','Weitere Arbeiten'];
const examples=[['Ausbaustufe','Technik'],['Ausbaustufe'],['Technik','Weitere Arbeiten']];
export const Offers=({returning=false}:{returning?:boolean})=>{
 const f=useCurrentFrame(); const {fps}=useVideoConfig();const t=f/fps;
 const open=returning?0:interpolate(t,[.85,1.45],[0,1],{extrapolateLeft:'clamp',extrapolateRight:'clamp'});
 const active=t<7.76?0:t<8.93?1:2;
 return <>
 {[0,1,2].map((i)=>{const bounce=returning?1:1+0.045*Math.sin(Math.PI*Math.min(1,t/0.7));return <div key={i} style={{...glass,position:'absolute',left:90+i*276,top:615,width:258,height:450,padding:20,transform:`translateY(${(1-bounce)*45}px)`,color:c.petrol}}>
 <div style={{fontSize:30,fontWeight:700,whiteSpace:'nowrap'}}>Angebot {['A','B','C'][i]}</div><div style={{fontSize:36,marginTop:12}}>Hauspreis</div>
 <div style={{display:'flex',justifyContent:'center',marginTop:20}}><House/></div>
 <div style={{fontSize:25,position:'absolute',left:20,bottom:24}}>Leistungen ↗</div>
 <div style={{position:'absolute',left:12,right:12,top:145,bottom:12,padding:16,borderRadius:18,background:'#e4eee0',transformOrigin:'bottom',transform:`rotateX(${90*(1-open)}deg)`,opacity:open}}>
 <div style={{fontSize:27,fontWeight:700,marginBottom:20}}>Enthalten:</div>
 {examples[i].map(n=><div key={n} style={{fontSize:26,lineHeight:1.25,padding:'12px 0',borderBottom:'1px solid #bccdbd',fontWeight:600,background:t>6&&n===names[active]?'#b6dcc0':'transparent',borderRadius:8,paddingLeft:6,transform:`translateX(${t>6&&n===names[active]?5:0}px)`}}>{n}</div>)}
 </div></div>})}
 {!returning&&t>1.45&&<div style={{position:'absolute',left:90,top:1100,width:810}}><div style={{fontSize:26,marginBottom:18}}>Beispielhafte Darstellung</div><div style={{...glass,padding:'16px 25px',fontSize:42,fontWeight:700,display:'flex',alignItems:'center',gap:22}}><span style={{display:'inline-flex',justifyContent:'center',alignItems:'center',width:56,height:56,borderRadius:28,background:c.mint,fontSize:32}}>{active+1}</span>{names[active]}</div></div>}
 </>;
};
